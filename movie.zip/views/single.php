<?php
/**
 * The Template for displaying all single posts.
 *
 * @package unite
 */

get_header(); ?>

	<div id="primary" class="content-area col-sm-12 <?php echo of_get_option( 'site_layout' ); ?>">
		<main id="main" class="site-main" role="main">

		<?php while ( have_posts() ) : the_post(); ?>

			            <div id="movie" <?php post_class(); ?>>
			<span class='col-sm-6'>
                <h2><?php the_title(); ?></h2>

			</span>
			<span class='col-sm-6'>

			</span>
			<span class='col-sm-6'>
				<?php the_content(); ?>	
			</span>
			<span class='col-sm-6'>
			<div class='tax_wrap'>
				<?php
				$cur_terms = get_the_terms( $post->ID , 'janr_tax' );
				foreach( $cur_terms as $cur_term ){
					echo '  <div class="janr"><i class="fa fa-file-video-o" aria-hidden="true"></i><a href="'. get_term_link( (int)$cur_term->term_id, $cur_term->taxonomy ) .'">'. $cur_term->name .'</a></div>';
				}
				?>
				</br>
				<?php
				$cur_terms = get_the_terms( $post->ID , 'country_tax' );
				foreach( $cur_terms as $cur_term ){
					echo '<div class="country"><i class="fa fa-globe" aria-hidden="true"></i><a href="'. get_term_link( (int)$cur_term->term_id, $cur_term->taxonomy ) .'">'. $cur_term->name .'</a></div>';
				}
				?>
				</br>
				<?php
				$cur_terms = get_the_terms( $post->ID , 'data_tax' );
				foreach( $cur_terms as $cur_term ){
					echo '<div class="year"><i class="fa fa-calendar" aria-hidden="true"></i> <a href="'. get_term_link( (int)$cur_term->term_id, $cur_term->taxonomy ) .'">'. $cur_term->name .'</a></div>';
				}
				?>
				</br>
				<div class='actor'><i class="fa fa-male" aria-hidden="true"></i> 
				<?php
				$cur_terms = get_the_terms( $post->ID , 'actor_tax' );
				foreach( $cur_terms as $cur_term ){
					echo '<a href="'. get_term_link( (int)$cur_term->term_id, $cur_term->taxonomy ) .'">'. $cur_term->name .'</a>   ';
				}
				?>
				</div>
			</div>	
				<div class='meta_box'>
			<?php 
				if ( $keys = get_post_custom_keys() ) {
					foreach ( (array) $keys as $key ) {
						$keyt = trim($key);
						if ( is_protected_meta( $keyt, 'post' ) )
							continue;
						$values = array_map('trim', get_post_custom_values($key));
						$value = implode($values,', ');
						if($key == 'm_date'){
						echo '<div><i class="fa fa-money" aria-hidden="true"></i><label>'.$value.'</label></div>';
						}
						if($key == 'actor'){
						echo '<div><i class="fa fa-calendar-o" aria-hidden="true"></i><label>'.$value.'</label></div>';
						}
					}
				}

			?>
			</div>
			</span>
            </div>

			<?php unite_post_nav(); ?>

			<?php
				// If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || '0' != get_comments_number() ) :
					comments_template();
				endif;
			?>

		<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>